package com.coderhouse.entity;
import javax.persistence.*;

import java.time.LocalDate;
import java.util.List;
@Entity
@Table(name = "ventas")
public class Ventas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;
    
    @OneToMany(mappedBy = "venta", cascade = CascadeType.ALL)
    private List<Producto> productos;
    
    private LocalDate fecha;

	public Ventas(Long id, Cliente cliente, List<Producto> productos, LocalDate fecha) {
		super();
		this.id = id;
		this.cliente = cliente;
		this.productos = productos;
		this.fecha = fecha;
	}

	public Ventas() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public List<Producto> getProductos() {
		return productos;
	}

	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}
    

}
